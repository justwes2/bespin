
def lambda_handler(event, context):
    # TODO implement
    return {
        'statusCode': 200,
        'headers' {
            'Content-Type': 'text/html; charset=utf-8'
        },
        'body': '<p>Hello World</p>'
    }
